<?php
namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Mailer\Mailer;

class IndexController extends AppController
{


public function index()
{
    $this->viewBuilder()->setLayout('home');
}

    
}