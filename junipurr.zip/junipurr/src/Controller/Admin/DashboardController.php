<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Mailer\Mailer;

class DashboardController extends AppController
{

    public function index()
    {
        $this->viewBuilder()->setLayout('admin');
    }

}