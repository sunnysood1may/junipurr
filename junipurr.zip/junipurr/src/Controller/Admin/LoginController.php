<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Mailer\Mailer;
use Cake\Http\Session;

class LoginController extends AppController
{
	
	
public function index()
{
    $this->viewBuilder()->setLayout('login');
    if(!empty( $this->request->getData() )){
        $data = $this->request->getData();
        $username = trim($data['username']);
        $password = md5(trim($data['password']));
        $userTable = TableRegistry::get('Users');  	
        $data = $userTable->find()->where(['Users.username'=>$username,'Users.password'=>$password])->first();         
        if(!empty($data)){
            $this->getRequest()->getSession()->write('ADMIN',$data);
            return $this->redirect('/admin/dashboard'); 
        } else {
            $this->Flash->error('Invalid username/password!');
        }
    }
    
    
}


public function logout()
{      
      $session = $this->request->getSession();
      $session->delete('ADMIN');      
      return $this->redirect('/admin'); 
}



}