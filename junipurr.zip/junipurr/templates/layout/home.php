<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="images/favicon.ico">
<title>junipurr</title>
</head>
<body>
<!--Header Start-->
<div class="message-shadow"></div>
<div class="clearfix"></div>
<section class="content">
    <div class="container">
        <div class="inner-page row">
            <div class="listing-view margin-bottom-20">
                <div class="row">JUNIPURR HOME PAGE FOR CHRIS</div>
            </div>
            <div class="clearfix"></div>
            <form method="post" action="#" class="listing_sort">
                <div class="select-wrapper pagination clearfix margin-top-none margin-bottom-15">
                    <div class="row">     
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right stones"></div>                                              
                    </div>
                </div>
            </form>
            <div class="clearfix"></div>
        </div>
    </div>
    <!--container ends--> 
</section>
<div class="clearfix"></div>
</body>
</html>